"""Outcome-blind, nested sampling for PX-COL-002."""

from __future__ import annotations

import numpy as np

STRATA = 16
WIDTH = 6_250
MULTIPLIER = 4


def pools(lower: int, seed: int, budget: int, phase: str) -> list[list[int]]:
    if phase not in {"development", "test"}:
        raise ValueError("unknown phase")
    if budget not in (64, 256, 1024) or lower < 2 or seed < 0:
        raise ValueError("invalid population, budget or seed")
    count = MULTIPLIER * budget // STRATA
    result = []
    for stratum in range(STRATA):
        rng = np.random.Generator(
            np.random.PCG64(
                np.random.SeedSequence([0x50584332, int(phase == "test"), lower, seed, stratum])
            )
        )
        seen: set[int] = set()
        ordered = []
        while len(ordered) < count:
            n = lower + stratum * WIDTH + int(rng.integers(WIDTH))
            if n not in seen:
                seen.add(n)
                ordered.append(n)
        result.append(ordered)
    return result
