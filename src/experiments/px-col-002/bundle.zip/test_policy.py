"""Semantic tests of prefix reuse, rational ranking, sampling and label isolation."""

import unittest
from fractions import Fraction
from unittest.mock import patch

from policy import Prefix, choose, finish, prefix, run_policy
from sampler import pools


class PrefixPolicyTests(unittest.TestCase):
    def test_known_arrival_and_first_one(self):
        self.assertEqual(finish(27), 111)
        self.assertEqual(prefix(1, 32), Prefix(1, 1, 0, 0))
        self.assertEqual(prefix(8, 32), Prefix(8, 1, 3, 0))

    def test_prefix_continuation_matches_direct(self):
        for n in range(2, 1500):
            for h in (0, 8, 16, 32):
                r = prefix(n, h)
                self.assertEqual(finish(r.endpoint, r.steps), finish(n))

    def test_exact_ranking_and_charged_discarded_prefixes(self):
        group = list(range(100, 180))
        selected, cost = choose(group, 10, "growth", 16)
        expected = sorted(
            (prefix(n, 16) for n in group), key=lambda r: (-Fraction(r.endpoint, r.n), r.n)
        )[:10]
        self.assertEqual(selected, expected)
        self.assertEqual(cost, sum(prefix(n, 16).steps for n in group))
        self.assertGreater(cost, sum(r.steps for r in selected))

    def test_nested_unique_size_strata_and_seed(self):
        a, b = pools(100001, 3, 64, "development"), pools(100001, 3, 1024, "development")
        self.assertEqual(a, [x[:16] for x in b])
        self.assertNotEqual(a, pools(100001, 4, 64, "development"))
        self.assertNotEqual(a, pools(100001, 3, 64, "test"))
        for s, group in enumerate(b):
            self.assertEqual(len(set(group)), 256)
            self.assertTrue(all(100001 + s * 6250 <= n < 100001 + (s + 1) * 6250 for n in group))

    def test_survival_ties_are_uniform(self):
        group = [99991, 99989, 99971]
        keep, _ = choose(group, 2, "survival", 1)
        self.assertEqual([r.n for r in keep], group[:2])

    def test_selector_does_not_request_full_outcomes(self):
        with patch("policy.finish", side_effect=AssertionError("suffix unavailable")):
            chosen, cost = choose(list(range(100001, 100101)), 10, "growth", 16)
        self.assertEqual(len(chosen), 10)
        self.assertEqual(cost, 1600)

    def test_deterministic_selection_and_cost(self):
        first = run_policy(100001, 0, 64, "development", "growth", 8)
        second = run_policy(100001, 0, 64, "development", "growth", 8)
        self.assertEqual(first["selected"], second["selected"])
        self.assertEqual(first["charged_transitions"], second["charged_transitions"])

    def test_invalid_inputs(self):
        for n, h in [(0, 8), (1, -1)]:
            with self.assertRaises(ValueError):
                prefix(n, h)
        with self.assertRaises(ValueError):
            choose([3, 3], 1, "growth", 8)


if __name__ == "__main__":
    unittest.main()
