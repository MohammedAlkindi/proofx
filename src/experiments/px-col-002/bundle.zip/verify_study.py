"""Independent recount for PX-COL-002; imports no selector, sampler or analysis code."""

from __future__ import annotations

import argparse
import copy
import csv
import gzip
import hashlib
import json
import math
from collections import defaultdict
from fractions import Fraction
from functools import cmp_to_key
from pathlib import Path
from statistics import median

import numpy as np


def insist(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def count_to_one(n: int) -> int:
    """Batch halving runs; no cache or generator arithmetic is used."""
    count = 0
    while n != 1:
        if n % 2:
            n = n * 3 + 1
            count += 1
        halvings = (n & -n).bit_length() - 1
        n >>= halvings
        count += halvings
        insist(count <= 100000, "independent reference fuel exhausted")
    return count


def recount_prefix(n: int, horizon: int) -> tuple[int, int, int]:
    x, count, odd = n, 0, 0
    while x != 1 and count < horizon:
        if x % 2:
            x = x * 3 + 1
            count += 1
            odd += 1
        else:
            shift = min((x & -x).bit_length() - 1, horizon - count)
            x >>= shift
            count += shift
    return x, count, odd


def regenerate_pool(lower: int, seed: int, budget: int, phase: str) -> list[list[int]]:
    groups = []
    for s in range(16):
        child = np.random.SeedSequence([0x50584332, 1 if phase == "test" else 0, lower, seed, s])
        gen = np.random.Generator(np.random.PCG64(child))
        group = []
        while len(group) < budget // 4:
            candidate = lower + 6250 * s + int(gen.integers(low=0, high=6250))
            if candidate not in group:
                group.append(candidate)
        groups.append(group)
    return groups


def old_bits(n: int) -> float:
    digits = bin(n)[2:]
    p = digits.count("1") / len(digits)
    ent = -p * math.log2(p) if p else 0.0
    if p < 1:
        ent -= (1 - p) * math.log2(1 - p)
    return 0.5 * min(1.0, max(0.0, p - math.log(2) / math.log(3)) / 0.2) + 0.5 * ent


def rational_compare(a: tuple, b: tuple) -> int:
    # a=(n, endpoint, steps, odds). Descending endpoint/n, ascending n.
    cross = a[1] * b[0] - b[1] * a[0]
    return -1 if cross > 0 else 1 if cross < 0 else (a[0] > b[0]) - (a[0] < b[0])


def check_row(row: dict, values: dict[int, int], labels: set[int], pool_cache: dict) -> dict:
    key = (row["lower"], row["seed"], row["budget"], row["phase"])
    if key not in pool_cache:
        pool_cache[key] = regenerate_pool(*key)
    groups = pool_cache[key]
    wanted = []
    screen = 0
    for group in groups:
        if row["method"] in ("growth", "odd_count", "survival"):
            rec = [(n, *recount_prefix(n, row["horizon"])) for n in group]
            screen += sum(r[2] for r in rec)
            if row["method"] == "growth":
                rec.sort(key=cmp_to_key(rational_compare))
            elif row["method"] == "odd_count":
                rec.sort(key=lambda r: (-r[3], r[0]))
            else:
                rec.sort(key=lambda r: r[1] == 1)
        else:
            ordered = list(group)
            if row["method"] == "ascending":
                ordered = sorted(ordered)
            elif row["method"] == "descending":
                ordered = sorted(ordered, reverse=True)
            elif row["method"] == "bit_score":
                ordered = sorted(ordered, key=lambda n: (-old_bits(n), n))
            else:
                insist(row["method"] == "uniform", "unknown policy")
            rec = [(n, n, 0, 0) for n in ordered]
        wanted.extend(rec[: row["budget"] // 16])
    insist(len(row["selected"]) == row["budget"], "wrong candidate budget")
    insist(len({r[0] for r in wanted}) == row["budget"], "duplicate candidate")
    continuation = 0
    for observed, expected in zip(row["selected"], wanted, strict=True):
        n, endpoint, steps, odds = expected
        insist(
            observed == [n, values[n], endpoint, steps, odds],
            "selected outcome or ordering mismatch",
        )
        continuation += values[n] - steps
    hits = sum(r[0] in labels for r in row["selected"])
    insist(row["hits"] == hits, "hit count mismatch")
    insist(row["screening_transitions"] == screen, "screening charge mismatch")
    insist(row["continuation_transitions"] == continuation, "continuation charge mismatch")
    insist(row["charged_transitions"] == screen + continuation, "total charge mismatch")
    insist(row["seconds"] > 0, "invalid elapsed time")
    return {
        "hits": hits,
        "work": screen + continuation,
        "screen": screen,
        "seconds": row["seconds"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    root = args.directory
    manifest = json.loads((root / "manifest.json").read_text())
    for name, digest in manifest["artifact_sha256"].items():
        insist(
            hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
            "artifact hash mismatch: " + name,
        )
    references = defaultdict(dict)
    written_labels = defaultdict(set)
    count = 0
    with gzip.open(root / "reference.csv.gz", "rt", newline="") as stream:
        for row in csv.DictReader(stream):
            n, t, lower = int(row["n"]), int(row["stopping_time"]), int(row["lower"])
            insist(n not in references[lower], "duplicate reference input")
            insist(t == count_to_one(n), "reference stopping time mismatch")
            insist(int(row["stratum"]) == (n - lower) // 6250, "reference stratum mismatch")
            references[lower][n] = t
            if int(row["target"]):
                written_labels[lower].add(n)
            count += 1
    labels = {}
    for lower, values in references.items():
        insist(set(values) == set(range(lower, lower + 100000)), "reference domain mismatch")
        found = set()
        for s in range(16):
            ordered = sorted(
                range(lower + s * 6250, lower + (s + 1) * 6250), key=lambda n: (-values[n], n)
            )
            found.update(ordered[:313])
        insist(found == written_labels[lower] and len(found) == 5008, "target labels mismatch")
        labels[lower] = found
    rows = [json.loads(line) for line in gzip.open(root / "runs.jsonl.gz", "rt")]
    phase = manifest["phase"]
    expected_lowers = (
        (100001, 400001, 800001) if phase == "development" else (2097152, 33554432, 536870912)
    )
    insist(set(references) == set(expected_lowers), "wrong intervals")
    expected_keys = set()
    methods = ("growth", "odd_count", "survival", "bit_score", "ascending", "descending", "uniform")
    if phase == "development":
        for lo in expected_lowers:
            for seed in range(16):
                expected_keys.add((lo, seed, 1024, "uniform", 0))
                for h in (8, 16, 32):
                    expected_keys.add((lo, seed, 1024, "growth", h))
    else:
        freeze = json.loads((root.parent / "freeze.json").read_text())
        insist(
            hashlib.sha256((root.parent / "freeze.json").read_bytes()).hexdigest()
            == manifest["freeze_sha256"],
            "freeze mismatch",
        )
        for name, digest in freeze["source_sha256"].items():
            insist(
                hashlib.sha256((root.parent / name).read_bytes()).hexdigest() == digest,
                "frozen source mismatch",
            )
        for lo in expected_lowers:
            for seed in range(32):
                for budget in (64, 256, 1024):
                    for m in methods:
                        expected_keys.add((lo, seed, budget, m, freeze["chosen_horizon"]))
    actual_keys = [(r["lower"], r["seed"], r["budget"], r["method"], r["horizon"]) for r in rows]
    insist(
        len(actual_keys) == len(set(actual_keys)) and set(actual_keys) == expected_keys,
        "missing or duplicated runs",
    )
    grouped = defaultdict(list)
    pool_cache = {}
    for row in rows:
        insist(row["phase"] == phase, "phase mismatch")
        checked = check_row(row, references[row["lower"]], labels[row["lower"]], pool_cache)
        grouped[(row["lower"], row["budget"], row["method"], row["horizon"])].append(checked)
    summary = json.loads((root / "summary.json").read_text())
    for aggregate in summary["rows"]:
        lower, budget = aggregate["lower"], aggregate["budget"]
        group = grouped[(lower, budget, aggregate["method"], aggregate["horizon"])]
        hits = sum(r["hits"] for r in group)
        work = sum(r["work"] for r in group)
        screen = sum(r["screen"] for r in group)
        expected_hits = Fraction(budget * 313, 6250)
        expected_cost = Fraction(budget * sum(references[lower].values()), 100000)
        rate = Fraction(hits, work)
        expected_fields = {
            "hits_sum": hits,
            "replicates": len(group),
            "hits_mean": hits / len(group),
            "hits_min": min(r["hits"] for r in group),
            "hits_max": max(r["hits"] for r in group),
            "charged_transitions_sum": work,
            "charged_transitions_mean": work / len(group),
            "screening_transitions_mean": screen / len(group),
            "screening_fraction": screen / work,
            "target_rate_exact": str(rate),
            "rate_ratio_to_uniform_expectation": str(rate / (expected_hits / expected_cost)),
            "targets_per_million_transitions": float(rate * 1000000),
            "precision_mean": hits / (len(group) * budget),
            "recall_mean": hits / (len(group) * 5008),
            "enrichment_to_uniform_expected_hits": hits / len(group) / float(expected_hits),
            "seconds_median": median(r["seconds"] for r in group),
            "seconds_min": min(r["seconds"] for r in group),
            "seconds_max": max(r["seconds"] for r in group),
        }
        for field, value in expected_fields.items():
            insist(aggregate[field] == value, "aggregate mismatch: " + field)
        insist(
            aggregate["uniform_exact_expectations"]
            == {
                "hits": str(expected_hits),
                "transitions": str(expected_cost),
                "targets_per_transition": str(expected_hits / expected_cost),
            },
            "exact baseline mismatch",
        )
    if phase == "development":
        rates = {
            h: Fraction(
                sum(r["hits"] for key, g in grouped.items() if key[2:] == ("growth", h) for r in g),
                sum(r["work"] for key, g in grouped.items() if key[2:] == ("growth", h) for r in g),
            )
            for h in (8, 16, 32)
        }
        chosen = max(rates, key=lambda h: (rates[h], -h))
        insist(summary["chosen_horizon"] == chosen, "development choice mismatch")
        for family in summary["development_family_scores"]:
            insist(
                Fraction(family["pooled_rate"]) == rates[family["horizon"]], "family score mismatch"
            )
    else:
        primary = [r for r in summary["rows"] if r["method"] == "growth" and r["budget"] == 1024]
        insist(summary["primary_endpoint"] == primary, "primary subset mismatch")
        insist(
            summary["predeclared_efficiency_criterion_met"]
            == all(Fraction(r["rate_ratio_to_uniform_expectation"]) > 1 for r in primary),
            "primary criterion mismatch",
        )
    altered = copy.deepcopy(rows[0])
    altered["selected"][0][1] += 1
    detected = False
    try:
        check_row(altered, references[altered["lower"]], labels[altered["lower"]], pool_cache)
    except ValueError:
        detected = True
    insist(detected, "deliberate corrupted stopping time was not detected")
    result = {
        "status": "passed",
        "phase": phase,
        "reference_inputs": count,
        "runs": len(rows),
        "selected_records": sum(len(r["selected"]) for r in rows),
        "reference_mismatches": 0,
        "all_rankings_pools_labels_costs_and_aggregates_checked": True,
        "negative_control_corruption_detected": detected,
        "independence_scope": "Separate batched-halving arithmetic, cross-product ratio comparator and recount. Shared NumPy and protocol; internal verification, not external review.",
    }
    (root / "verification.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
