"""PX-COL-002 development and frozen fresh-range evaluation. Python 3.13+ / NumPy."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np

from analysis import choose_horizon, summarize, targets
from policy import FUEL, METHODS, run_policy

ROOT = Path(__file__).resolve().parent
DEV_LOWER = (100001, 400001, 800001)
TEST_LOWER = (2097152, 33554432, 536870912)
N = 100_000
BUDGETS = (64, 256, 1024)
SOURCES = (
    "sampler.py",
    "policy.py",
    "analysis.py",
    "run_study.py",
    "test_policy.py",
    "protocol.md",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, data: dict) -> None:
    path.write_text(
        json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )


def gz_writer(path: Path):
    return io.TextIOWrapper(
        gzip.GzipFile(filename="", mode="wb", fileobj=path.open("wb"), mtime=0),
        encoding="utf-8",
        newline="",
    )


def reference(lower: int) -> dict[int, int]:
    """Reference-only memoization; this cache is never available to a policy."""
    cache = {1: 0}
    values = {}
    for n in range(lower, lower + N):
        x, path = n, []
        while x not in cache:
            if len(path) >= FUEL:
                raise RuntimeError(f"unresolved reference input {n}")
            path.append(x)
            x = 3 * x + 1 if x & 1 else x // 2
        t = cache[x]
        for x in reversed(path):
            t += 1
            cache[x] = t
        if cache[n] > FUEL:
            raise RuntimeError(f"reference fuel exceeded for {n}")
        values[n] = cache[n]
    return values


def old_references(path: Path) -> dict[int, dict[int, int]]:
    if sha(path) != "f004f8c887b733c5a531cc42b22b0ea476f57562e4e6aa9793a163f31e354a8c":
        raise RuntimeError("development reference does not match PX-COL-001")
    refs = {lower: {} for lower in DEV_LOWER}
    with gzip.open(path, "rt", newline="") as stream:
        for row in csv.DictReader(stream):
            n = int(row["n"])
            for lower in DEV_LOWER:
                if lower <= n < lower + N:
                    refs[lower][n] = int(row["stopping_time"])
    if any(len(v) != N for v in refs.values()):
        raise RuntimeError("incomplete development table")
    return refs


def save_references(out: Path, refs: dict[int, dict[int, int]]) -> None:
    with gz_writer(out / "reference.csv.gz") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["n", "stopping_time", "lower", "stratum", "target"])
        for lower, values in refs.items():
            labels = targets(values, lower)
            for n, tau in sorted(values.items()):
                writer.writerow([n, tau, lower, (n - lower) // 6250, int(n in labels)])


def save_runs(out: Path, rows: list[dict]) -> None:
    with gz_writer(out / "runs.jsonl.gz") as stream:
        for row in rows:
            stream.write(json.dumps(row, separators=(",", ":")) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("development", "test"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--legacy-reference", type=Path)
    parser.add_argument("--freeze", type=Path, default=ROOT / "freeze.json")
    parser.add_argument("--freeze-commit")
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("use a new output directory; existing runs are never replaced")
    frozen = None
    if args.phase == "test":
        if not args.freeze_commit or len(args.freeze_commit) != 40:
            raise RuntimeError("record the full pushed freeze commit before test")
        frozen = json.loads(args.freeze.read_text())
        for name in SOURCES:
            if frozen["source_sha256"][name] != sha(ROOT / name):
                raise RuntimeError("source differs from frozen version: " + name)
        if frozen["chosen_horizon"] not in (8, 16, 32):
            raise RuntimeError("invalid frozen horizon")
    elif args.legacy_reference is None:
        raise RuntimeError("development requires the existing PX-COL-001 table")
    args.output.mkdir(parents=True)
    total_start = time.perf_counter()
    rows = []
    if args.phase == "development":
        refs = old_references(args.legacy_reference)
        for lower in DEV_LOWER:
            for seed in range(16):
                rows.append(run_policy(lower, seed, 1024, "development", "uniform", 0))
                for h in (8, 16, 32):
                    rows.append(run_policy(lower, seed, 1024, "development", "growth", h))
            print(f"development policies complete for {lower}", flush=True)
    else:
        # No reference table or outcome-dependent selection is constructed here.
        h = frozen["chosen_horizon"]
        for block, lower in enumerate(TEST_LOWER):
            for bi, budget in enumerate(BUDGETS):
                for seed in range(32):
                    offset = (seed + block + bi) % len(METHODS)
                    order = METHODS[offset:] + METHODS[:offset]
                    for method in order:
                        rows.append(run_policy(lower, seed, budget, "test", method, h))
                print(f"fresh policies complete: lower={lower}, budget={budget}", flush=True)
        # Persist all selected outcomes before generating full-domain labels.
        save_runs(args.output, rows)
        refs = {}
        for lower in TEST_LOWER:
            refs[lower] = reference(lower)
            print(f"fresh reference complete for {lower}", flush=True)
    summary = summarize(rows, refs)
    if args.phase == "development":
        h, scores = choose_horizon(summary)
        summary["chosen_horizon"] = h
        summary["development_family_scores"] = scores
    else:
        primary = [r for r in summary["rows"] if r["method"] == "growth" and r["budget"] == 1024]
        from fractions import Fraction

        summary["predeclared_efficiency_criterion_met"] = all(
            Fraction(r["rate_ratio_to_uniform_expectation"]) > 1 for r in primary
        )
        summary["primary_endpoint"] = primary
    save_runs(args.output, rows)
    save_references(args.output, refs)
    write_json(args.output / "summary.json", summary)
    manifest = {
        "study": "PX-COL-002",
        "phase": args.phase,
        "python": sys.version,
        "numpy": np.__version__,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpus": os.cpu_count(),
        "freeze_commit": args.freeze_commit,
        "fuel": FUEL,
        "source_sha256": {name: sha(ROOT / name) for name in SOURCES},
        "artifact_sha256": {
            name: sha(args.output / name)
            for name in ("reference.csv.gz", "runs.jsonl.gz", "summary.json")
        },
        "elapsed_seconds_nonbenchmark": time.perf_counter() - total_start,
    }
    if frozen is not None:
        manifest["freeze_sha256"] = sha(args.freeze)
    write_json(args.output / "manifest.json", manifest)
    print(
        json.dumps(
            {
                "phase": args.phase,
                "rows": len(rows),
                "chosen_horizon": summary.get("chosen_horizon"),
                "criterion_met": summary.get("predeclared_efficiency_criterion_met"),
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
