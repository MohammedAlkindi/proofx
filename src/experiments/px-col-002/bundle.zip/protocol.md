# PX-COL-002: finite-prefix selection with charged screening

## Phase A: fixed development procedure, before new outcomes

This is a prospective finite range-transfer experiment, not a proof of Collatz
or an external preregistration. Disjoint starting intervals can share trajectory
suffixes. All evaluations use ordinary C(n)=n/2 for even n and 3n+1 for odd n,
exact integers, stopping at the first 1. Fuel is 100,000 ordinary transitions.
Any unresolved reference or selected input prevents a completed-data comparison.

Development starting intervals, inclusive: [100001,200000], [400001,500000],
[800001,900000]. Their outcomes already exist in PX-COL-001 and are development
data. No complete trajectory or label with a starting input above one million
will be generated for the new test until Phase B's chosen parameters, code
hashes and protocol are committed and pushed.

Each interval contains 100,000 inputs, partitioned into 16 consecutive strata
of 6,250. Each stratum's 313 largest total stopping times (ties: smaller input
first) are targets: 5,008 targets per interval. Labels are used only in analysis.

For a budget B in {64,256,1024}, each stratum receives q=B/16 complete evaluations.
An outcome-independent seeded NumPy generator draws an ordered pool of 4q
distinct inputs per stratum. A shared pool supports all methods at a fixed
interval/seed/budget. Smaller budgets use prefixes of the largest pool. Seeds
are 0..15 for development and 0..31 for the fresh test. The sampler is specified
in sampler.py: PCG64 from SeedSequence([0x50584332, phase_id, lower, seed, stratum]),
with phase_id 0 for development and 1 for test. Draw uniform integer offsets one
at a time, rejecting duplicates until 4q unique values are obtained. This gives
the required nested pool prefixes. NumPy and Python versions are recorded.

Revised policy: run at most h ordinary transitions for every pooled input,
stopping earlier at 1. Rank descending by the exact rational endpoint/input
ratio, ties by smaller input, and choose q per stratum. Complete selected
trajectories from their saved endpoints. There is no anchor, outcome lookup,
trained suffix table, or cache available to selection or evaluation.

The only family searched is h in {8,16,32}, with fixed oversampling factor 4.
Select h maximizing pooled target hits / charged ordinary transitions at B=1024
over all three development intervals and all 16 seeds. Break exact ties by the
smaller h. Keep all development results. No other score or parameter may be
chosen on fresh outcomes. Persist the chosen h, development artifact hashes and
source hashes in freeze.json, then commit/push Phase B before fresh evaluation.

## Fresh test, parameters to be frozen in Phase B

Starting intervals (inclusive): [2097152,2197151], [33554432,33654431],
[536870912,536970911]. These were selected geometrically, without evaluating
their stopping-time outcomes in this study. They are not new verification
territory and are not claimed to be unvisited by historical experiments.

Compare all budgets and seeds with identical size quotas and candidate pools:

1. prefix growth, using the h selected on development data;
2. prefix odd-count ablation, descending number of odd transitions, ties by n;
3. prefix survival ablation, nonterminated inputs first, ties by pool order;
4. the old ProofX quick input-bit score, ties by n (no prefix computation);
5. ascending pooled inputs (no prefix computation);
6. descending pooled inputs (no prefix computation);
7. uniform, the first q pool entries (no prefix computation).

Bit priority reproduces the old numerical quick score but uses this experiment's
common proposal distribution. It is not the old anchor-expansion policy; the
existing PX-COL-001 negative result must remain reported separately.

Primary endpoint: at B=1024, the growth policy's pooled hits / pooled charged
transitions for each of the three fresh intervals (32 seeds). Compare with the
matched-uniform exact expectation rate E[hits]/E[transitions]. This ratio of
expectations is not the expectation of a run-wise ratio. Call the predeclared
efficiency criterion met only if the growth rate exceeds that reference in all
three intervals; otherwise report it unmet. No p-value or infinite-population
claim is specified. All finite results are reported regardless of direction.

Secondary endpoints: hits, precision, recall, enrichment over exact matched
uniform expected hits, charged transitions, targets per million transitions,
screening fraction, and measured single-process end-to-end time. Give mean and
range across seeds; use medians and range for timing. All other budget/policy
contrasts and per-range effects are descriptive. Seeds are algorithmic
replications on fixed deterministic labels, not independent mathematical inputs.

For prefix methods charge every screening transition, including discarded
inputs, plus continuation transitions for selected inputs. Reuse selected
prefixes; do not charge them twice. Other policies charge all selected ordinary
transitions. Ranking/sampling/queue arithmetic has no integer-transition charge
but is included in wall time. Reference-table generation, labels, file output
and verification are excluded from policy timing and reported separately. No
cache, packed-step acceleration or cross-policy reuse is used in timed policies.
Timing uses a fixed seed-rotated method order. It is a local benchmark, not a
hardware-independent efficiency result or a verification-record claim.

## Checks and preservation

Write policy selections before constructing fresh reference outcomes. Selector
APIs have no outcome/reference argument. A complete exact reference table is
then generated and independently recounted with a different implementation.
Verify all labels, selected stopping times, sampler outputs, size quotas,
ranking/tie rules, cost decompositions, aggregate fields and exact expectations.
Check that selected inputs are unchanged when reference labels are absent or
replaced, and that a deliberately changed result fails checking. Archive source
hashes, commands, environment, raw pools/selections, timings and failures.

Version 1.1, 3 November 2026. Before any development run, the sampler specification
was aligned with ProofX's seeded-NumPy requirement; this was not an outcome-driven
change. Changes after freeze must be recorded as deviations,
with no replacement of unfavorable results by a retuned test.
