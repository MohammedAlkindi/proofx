"""Finite labels, exact uniform expectations and fully reported aggregates."""

from __future__ import annotations

from collections import defaultdict
from fractions import Fraction
from statistics import median

from sampler import STRATA, WIDTH


def targets(values: dict[int, int], lower: int) -> set[int]:
    labels = set()
    for s in range(STRATA):
        group = range(lower + s * WIDTH, lower + (s + 1) * WIDTH)
        labels.update(sorted(group, key=lambda n: (-values[n], n))[:313])
    return labels


def expectations(values: dict[int, int], lower: int, budget: int) -> dict:
    quota = budget // STRATA
    expected_hits = Fraction(STRATA * quota * 313, WIDTH)
    expected_cost = sum(
        (
            Fraction(quota, WIDTH)
            * sum(values[n] for n in range(lower + s * WIDTH, lower + (s + 1) * WIDTH))
            for s in range(STRATA)
        ),
        Fraction(),
    )
    return {
        "hits": str(expected_hits),
        "transitions": str(expected_cost),
        "targets_per_transition": str(expected_hits / expected_cost),
    }


def summarize(runs: list[dict], references: dict[int, dict[int, int]]) -> dict:
    groups = defaultdict(list)
    for row in runs:
        groups[(row["lower"], row["budget"], row["method"], row["horizon"])].append(row)
    output = []
    for (lower, budget, method, horizon), rows in sorted(groups.items()):
        labels = targets(references[lower], lower)
        hit_values = [sum(n in labels for n, *_ in r["selected"]) for r in rows]
        for r, hits in zip(rows, hit_values, strict=True):
            r["hits"] = hits
            for n, tau, *_ in r["selected"]:
                if tau != references[lower][n]:
                    raise AssertionError(f"selected stopping time mismatch: {n}")
        work = [r["charged_transitions"] for r in rows]
        screens = [r["screening_transitions"] for r in rows]
        seconds = [r["seconds"] for r in rows]
        exact = expectations(references[lower], lower, budget)
        rate = Fraction(sum(hit_values), sum(work))
        base_rate = Fraction(exact["targets_per_transition"])
        output.append(
            {
                "lower": lower,
                "upper": lower + STRATA * WIDTH - 1,
                "budget": budget,
                "method": method,
                "horizon": horizon,
                "replicates": len(rows),
                "hits_sum": sum(hit_values),
                "hits_mean": sum(hit_values) / len(rows),
                "hits_min": min(hit_values),
                "hits_max": max(hit_values),
                "precision_mean": sum(hit_values) / (len(rows) * budget),
                "recall_mean": sum(hit_values) / (len(rows) * len(labels)),
                "charged_transitions_sum": sum(work),
                "charged_transitions_mean": sum(work) / len(rows),
                "screening_transitions_mean": sum(screens) / len(rows),
                "screening_fraction": sum(screens) / sum(work),
                "target_rate_exact": str(rate),
                "targets_per_million_transitions": float(rate * 1_000_000),
                "rate_ratio_to_uniform_expectation": str(rate / base_rate),
                "enrichment_to_uniform_expected_hits": sum(hit_values)
                / len(rows)
                / float(Fraction(exact["hits"])),
                "uniform_exact_expectations": exact,
                "seconds_median": median(seconds),
                "seconds_min": min(seconds),
                "seconds_max": max(seconds),
            }
        )
    return {"rows": output}


def choose_horizon(summary: dict) -> tuple[int, list[dict]]:
    scores = []
    for h in (8, 16, 32):
        rows = [r for r in summary["rows"] if r["method"] == "growth" and r["horizon"] == h]
        score = Fraction(
            sum(r["hits_sum"] for r in rows), sum(r["charged_transitions_sum"] for r in rows)
        )
        scores.append(
            {
                "horizon": h,
                "pooled_rate": str(score),
                "targets_per_million_transitions": float(score * 1_000_000),
            }
        )
    winner = max(scores, key=lambda r: (Fraction(r["pooled_rate"]), -r["horizon"]))
    return winner["horizon"], scores
