"""Finite-prefix Collatz policies. No reference labels or suffix cache enter here."""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from time import perf_counter_ns

from sampler import STRATA, pools

FUEL = 100_000
METHODS = ("growth", "odd_count", "survival", "bit_score", "ascending", "descending", "uniform")


@dataclass(frozen=True)
class Prefix:
    n: int
    endpoint: int
    steps: int
    odd_steps: int


def prefix(n: int, horizon: int) -> Prefix:
    if n < 1 or horizon < 0 or horizon > FUEL:
        raise ValueError("invalid prefix argument")
    x, steps, odd = n, 0, 0
    while x != 1 and steps < horizon:
        if x & 1:
            x = 3 * x + 1
            odd += 1
        else:
            x //= 2
        steps += 1
    return Prefix(n, x, steps, odd)


def finish(x: int, used: int = 0) -> int:
    if x < 1 or used < 0 or used > FUEL:
        raise ValueError("invalid continuation")
    t = used
    while x != 1 and t < FUEL:
        x = 3 * x + 1 if x & 1 else x // 2
        t += 1
    if x != 1:
        raise RuntimeError("unresolved within ordinary-transition fuel")
    return t


def bit_score(n: int) -> float:
    """Numerically the old quick input-bit score, not full-path parity excess."""
    p = n.bit_count() / n.bit_length()
    ent = -p * math.log2(p) if p else 0.0
    if p < 1:
        ent -= (1 - p) * math.log2(1 - p)
    excess = max(0.0, p - math.log(2) / math.log(3))
    return 0.5 * min(1.0, excess / 0.2) + 0.5 * ent


def choose(group: list[int], quota: int, method: str, horizon: int) -> tuple[list[Prefix], int]:
    """Return selected prefixes and the charged work on the entire pool."""
    if method not in METHODS or not 0 < quota <= len(group):
        raise ValueError("invalid selection request")
    if len(set(group)) != len(group) or any(n < 2 for n in group):
        raise ValueError("pool must contain distinct inputs >=2")
    if method in {"growth", "odd_count", "survival"}:
        records = [prefix(n, horizon) for n in group]
        screening = sum(r.steps for r in records)
        if method == "growth":
            records.sort(key=lambda r: (-Fraction(r.endpoint, r.n), r.n))
        elif method == "odd_count":
            records.sort(key=lambda r: (-r.odd_steps, r.n))
        else:
            # Stable sort preserves random pool order when survival ties.
            records.sort(key=lambda r: r.endpoint == 1)
        return records[:quota], screening
    values = group[:]
    if method == "bit_score":
        values.sort(key=lambda n: (-bit_score(n), n))
    elif method == "ascending":
        values.sort()
    elif method == "descending":
        values.sort(reverse=True)
    return [Prefix(n, n, 0, 0) for n in values[:quota]], 0


def run_policy(lower: int, seed: int, budget: int, phase: str, method: str, horizon: int) -> dict:
    """Timed actual selection + continuation; no reference argument or global cache."""
    start = perf_counter_ns()
    groups = pools(lower, seed, budget, phase)
    selected, screening = [], 0
    for group in groups:
        keep, work = choose(group, budget // STRATA, method, horizon)
        screening += work
        selected.extend(keep)
    observations = []
    continuation = 0
    for r in selected:
        total = finish(r.endpoint, r.steps)
        continuation += total - r.steps
        observations.append([r.n, total, r.endpoint, r.steps, r.odd_steps])
    elapsed = (perf_counter_ns() - start) / 1e9
    return {
        "lower": lower,
        "seed": seed,
        "budget": budget,
        "phase": phase,
        "method": method,
        "horizon": horizon,
        "screening_transitions": screening,
        "continuation_transitions": continuation,
        "charged_transitions": screening + continuation,
        "seconds": elapsed,
        "selected": observations,
    }
